#!/usr/bin/env python3
"""One-peer FRR graceful-restart kernel-route retention reproducer."""
import argparse
import ipaddress
import json
from pathlib import Path
import secrets
import signal
import subprocess
import sys
import time

IMAGE = "quay.io/frrouting/frr@sha256:89e5e1ec8b17c5dffaf57dbac58a29ebeb3731a84e5bc09dad1662adff2ba7f5"
HERE = Path(__file__).resolve().parent
PREFIX = "2001:db0::/64"
LABEL = "frr-gr-reproducer.owner"
DURATION = 135


def records(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def classify(code, rows):
    summaries = [r for r in rows if r.get("kind") == "summary"]
    if len(summaries) != 1:
        return 2, "inconclusive: no unique observer summary"
    s = summaries[0]
    if (s.get("window_complete") is not True or s.get("observer_loss") is not False or
            s.get("query_errors") != 0 or s.get("termination_signal") is not None or
            s.get("requested_duration_seconds") != DURATION or
            s.get("elapsed_seconds", 0) < DURATION or s.get("samples", 0) < 1 or
            not isinstance(s.get("absence_observed"), bool)):
        return 2, "inconclusive: observation interrupted or unreliable"
    if s.get("absence_observed") and code == 1:
        return 1, "reproduced: complete kernel route dump observed the prefix absent"
    if not s.get("absence_observed") and code == 0:
        return 0, "not reproduced: no absence observed during the completed window"
    return 2, "inconclusive: observer exit and summary disagree"


class Run:
    def __init__(self, out, subnet_id):
        self.out = out
        self.owner = secrets.token_hex(8)
        self.name = "frr-gr-" + self.owner
        self.containers = []
        self.monitor = None
        self.streams = []
        self.commands = (out / "commands.jsonl").open("w")
        self.timeline = (out / "timeline.jsonl").open("w")
        self.cleanup_failed = False
        self.v4 = ipaddress.IPv4Network(f"10.203.{subnet_id}.0/24")
        self.v6 = ipaddress.IPv6Network(f"fd42:203:{subnet_id:x}::/64")
        self.anchor = self.name + "-net"
        self.peer = self.name + "-peer"

    def event(self, kind, **data):
        row = dict(kind=kind, monotonic_ns=time.monotonic_ns(),
                   realtime_ns=time.time_ns(), **data)
        print(json.dumps(row), file=self.timeline, flush=True)
        print(json.dumps(row), flush=True)

    def call(self, *args, check=True, timeout=90):
        started = time.monotonic_ns()
        result = subprocess.run(args, text=True, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, timeout=timeout)
        print(json.dumps(dict(argv=args, started_monotonic_ns=started,
                              completed_monotonic_ns=time.monotonic_ns(),
                              exit=result.returncode)), file=self.commands, flush=True)
        if check and result.returncode:
            raise RuntimeError(f"command failed ({result.returncode}): {args!r}\n{result.stdout}")
        return result

    def pod(self, *args, **kwargs):
        return self.call("podman", *args, **kwargs).stdout

    def start(self, suffix, *args):
        name = self.name + "-" + suffix
        # Track intended names before creating resources. Cleanup checks the owner
        # label, so an interrupted or failed create cannot remove another run.
        self.containers.append(name)
        self.pod("run", "-d", "--pull=never", "--name", name,
                 "--label", f"{LABEL}={self.owner}", *args)
        return name

    def config(self, name, node):
        cfg = self.out / name
        cfg.mkdir()
        daemons = (HERE / "daemons").read_text()
        if not node:
            daemons = daemons.replace(" -p 0", "")
        desired = (HERE / ("node.conf" if node else "peer.conf")).read_text()
        desired = desired.replace("@NODE_V6@", str(self.v6[4]))
        desired = desired.replace("@PEER_V6@", str(self.v6[5]))
        desired = desired.replace("@PEER_V4@", str(self.v4[5]))
        (self.out / (name + "-desired.conf")).write_text(desired)
        for filename, text in (
                ("daemons", daemons),
                ("vtysh.conf", (HERE / "vtysh.conf").read_text()),
                ("frr.conf", (HERE / "startup.conf").read_text() if node else desired)):
            path = cfg / filename
            path.write_text(text)
            path.chmod(0o666)
        return cfg

    def generation(self, number):
        cfg = self.config(f"node{number}", True)
        sockets = self.out / f"run{number}"
        sockets.mkdir(mode=0o777)
        sockets.chmod(0o777)
        sandbox = self.start(f"pid{number}", "--pid", "private",
                             "--network", "container:" + self.anchor,
                             "--entrypoint", "sleep", IMAGE, "infinity")
        app = self.start(f"node{number}", "--network", "container:" + self.anchor,
                         "--pid", "container:" + sandbox, "--cap-add", "NET_ADMIN",
                         "--cap-add", "NET_RAW", "--cap-add", "SYS_ADMIN",
                         "-e", "TINI_SUBREAPER=true", "-v", f"{cfg}:/etc/frr:Z",
                         "-v", f"{sockets}:/var/run/frr:z",
                         "-v", f"{self.out}:/lab:z", "--entrypoint", "/bin/sh",
                         IMAGE, "-c", "/sbin/tini -- /usr/lib/frr/docker-start")
        self.event("node_start", generation=number, container=app)
        time.sleep(3)
        self.event("reload_begin", generation=number)
        result = self.pod("exec", app, "python3", "/usr/lib/frr/frr-reload.py",
                          "--reload", "--overwrite", "--stdout",
                          f"/lab/node{number}-desired.conf")
        (self.out / f"reload{number}.log").write_text(result)
        self.event("reload_end", generation=number)
        return app, sandbox

    def routes(self):
        return json.loads(self.pod("exec", self.anchor, "ip", "-j", "-6",
                                   "route", "show", "table", "main", "exact", PREFIX))

    def neighbors(self, container, filename):
        data = self.pod("exec", container, "vtysh", "-d", "bgpd", "-c",
                        "show bgp vrf all neighbors json")
        (self.out / filename).write_text(data)
        return json.loads(data)["default"][str(self.v6[5])]

    def baseline(self, app, label, min_connections=1):
        deadline = time.monotonic() + 65
        while time.monotonic() < deadline:
            routes = self.routes()
            if routes and all(r.get("dst") == PREFIX and
                              r.get("protocol") in ("bgp", 186) for r in routes):
                peer = self.neighbors(app, label + "-neighbors.json")
                if (peer.get("bgpState") == "Established" and
                        peer.get("connectionsEstablished", 0) >= min_connections):
                    (self.out / (label + "-route.json")).write_text(json.dumps(routes, indent=2))
                    return peer
            time.sleep(0.2)
        raise RuntimeError("baseline BGP route/session did not become ready: " + label)

    def execute(self):
        (self.out / "image.json").write_text(self.pod("image", "inspect", IMAGE))
        (self.out / "podman-version.txt").write_text(self.pod("version"))
        (self.out / "kernel.txt").write_text(self.call("uname", "-srvm").stdout)
        self.pod("network", "create", "--label", f"{LABEL}={self.owner}",
                 "--ipv6", "--subnet", str(self.v4), "--subnet", str(self.v6), self.name)
        self.start("net", "--pid", "private",
                   "--network", f"{self.name}:ip={self.v4[4]},ip6={self.v6[4]}",
                   "--cap-add", "NET_ADMIN", "--entrypoint", "sleep", IMAGE, "infinity")
        cfg = self.config("peer", False)
        self.start("peer", "--pid", "private",
                   "--network", f"{self.name}:ip={self.v4[5]},ip6={self.v6[5]}",
                   "--cap-add", "NET_ADMIN", "--cap-add", "NET_RAW", "--cap-add", "SYS_ADMIN",
                   "-v", f"{cfg}:/etc/frr:Z", "--entrypoint", "/bin/sh", IMAGE,
                   "-c", "/sbin/tini -- /usr/lib/frr/docker-start")
        app, sandbox = self.generation(0)
        self.baseline(app, "initial")
        self.event("helper_prepare_begin", restart_seconds=1)
        for label, commands in (
                ("shutdown", ["bgp graceful-restart restart-time 1", "bgp shutdown"]),
                ("resume", ["no bgp shutdown"])):
            args = ["exec", self.peer, "vtysh", "-d", "bgpd", "-c", "configure terminal",
                    "-c", "router bgp 4200000000"]
            for command in commands:
                args.extend(["-c", command])
            (self.out / ("helper-" + label + ".log")).write_text(self.pod(*args))
        time.sleep(1.25)
        before = self.baseline(app, "helper-before-clear")
        (self.out / "helper-clear.log").write_text(
            self.pod("exec", self.peer, "vtysh", "-d", "bgpd", "-c",
                     "clear bgp " + str(self.v6[4])))
        peer = self.baseline(app, "baseline", before["connectionsEstablished"] + 1)
        gr = peer.get("gracefulRestartInfo", {})
        if gr.get("rBit") is not False or gr.get("remoteGrMode") != "Helper":
            raise RuntimeError("fresh helper OPEN did not have R bit clear and Helper mode")
        self.event("helper_prepared", received_rbit=False, remote_mode="Helper",
                   connections_established=peer["connectionsEstablished"])
        (self.out / "frr-version.txt").write_text(
            self.pod("exec", app, "vtysh", "-c", "show version"))
        watch = self.out / "route-watch.jsonl"
        source, output = (HERE / "route-watch.py").open(), watch.open("w")
        self.streams.extend([source, output])
        self.monitor = subprocess.Popen(
            ["podman", "exec", "-i", self.anchor, "python3", "-u", "-", PREFIX,
             "--duration", str(DURATION), "--poll-ms", "10"],
            stdin=source, stdout=output, stderr=subprocess.STDOUT)
        for _ in range(100):
            if '"kind":"ready"' in watch.read_text():
                break
            if self.monitor.poll() is not None:
                raise RuntimeError("observer exited before ready: " + watch.read_text())
            time.sleep(0.1)
        else:
            raise RuntimeError("observer did not become ready")
        self.event("restart_begin", metrics="absent", network_namespace=self.anchor)
        self.pod("stop", "--time", "10", app)
        (self.out / "node0.log").write_text(self.pod("logs", "--timestamps", app))
        self.pod("rm", app)
        self.containers.remove(app)
        self.pod("stop", "--time", "1", sandbox)
        self.pod("rm", sandbox)
        self.containers.remove(sandbox)
        self.event("old_stopped", kernel_routes=self.routes())
        app, _ = self.generation(1)
        if self.monitor.poll() is not None:
            raise RuntimeError("observation ended before replacement configuration completed")
        code = self.monitor.wait(timeout=DURATION + 15)
        replacement = self.neighbors(app, "replacement-neighbors.json")
        if replacement.get("bgpState") != "Established":
            raise RuntimeError("replacement BGP session did not become Established")
        (self.out / "replacement-route.json").write_text(json.dumps(self.routes(), indent=2))
        result, meaning = classify(code, records(watch))
        self.event("result", exit=result, meaning=meaning, observer_exit=code)
        return result

    def cleanup(self):
        def failed(resource, exc):
            self.cleanup_failed = True
            try:
                self.event("cleanup_error", resource=resource, error=str(exc))
            except Exception:
                pass  # failure to write diagnostics must not prevent cleanup
        try:
            if self.monitor is not None and self.monitor.poll() is None:
                self.monitor.terminate()
                try:
                    self.monitor.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    self.monitor.kill()
                    self.monitor.wait(timeout=5)
        except ProcessLookupError:
            pass  # already exited between poll and terminate/kill
        except Exception as exc:
            failed("observer", exc)
        for stream in self.streams:
            try:
                stream.close()
            except Exception as exc:
                failed("observer stream", exc)
        for name in reversed(self.containers):
            try:
                inspected = self.call("podman", "inspect", name, check=False, timeout=15)
                if inspected.returncode:
                    raise RuntimeError(inspected.stdout)
                metadata = json.loads(inspected.stdout)[0]
                if (metadata.get("Config", {}).get("Labels") or {}).get(LABEL) != self.owner:
                    raise RuntimeError("owner label mismatch; resource left untouched")
                container_id = metadata["Id"]
                try:
                    (self.out / (name + ".log")).write_text(
                        self.pod("logs", "--timestamps", container_id, timeout=15))
                finally:
                    removed = self.call("podman", "rm", "--force", container_id,
                                        check=False, timeout=30)
                    if removed.returncode:
                        failed(name, removed.stdout)
            except Exception as exc:
                failed(name, exc)
        try:
            inspected = self.call("podman", "network", "inspect", self.name,
                                  check=False, timeout=15)
            if inspected.returncode:
                raise RuntimeError(inspected.stdout)
            network = json.loads(inspected.stdout)[0]
            if (network.get("labels") or {}).get(LABEL) != self.owner:
                raise RuntimeError("owner label mismatch; resource left untouched")
            removed = self.call("podman", "network", "rm", network["id"],
                                check=False, timeout=30)
            if removed.returncode:
                failed(self.name, removed.stdout)
        except Exception as exc:
            failed(self.name, exc)
        self.commands.close()
        self.timeline.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True, help="new evidence directory")
    parser.add_argument("--subnet-id", type=int, default=secrets.randbelow(240) + 10,
                        help="1..254; addresses are 10.203.ID.0/24 and fd42:203:ID::/64")
    args = parser.parse_args()
    if not 1 <= args.subnet_id <= 254:
        parser.error("subnet-id must be 1..254")
    args.output = args.output.resolve()
    try:
        args.output.mkdir(parents=True, exist_ok=False)
        run = Run(args.output, args.subnet_id)
    except Exception as exc:
        print(f"setup failed: {exc}", file=sys.stderr)
        return 2
    def interrupted(sig, _):
        raise KeyboardInterrupt(f"signal {sig}")
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, interrupted)
    result = 2
    try:
        run.event("start", image=IMAGE, output=str(args.output),
                  ipv4_subnet=str(run.v4), ipv6_subnet=str(run.v6))
        result = run.execute()
    except (Exception, KeyboardInterrupt) as exc:
        try:
            run.event("inconclusive", error=str(exc))
        except Exception:
            print(f"inconclusive: {exc}", file=sys.stderr)
    finally:
        for sig in (signal.SIGINT, signal.SIGTERM):
            signal.signal(sig, signal.SIG_IGN)
        try:
            run.cleanup()
        except Exception as exc:
            run.cleanup_failed = True
            print(f"cleanup failed: {exc}", file=sys.stderr)
    return 2 if run.cleanup_failed else result


if __name__ == "__main__":
    sys.exit(main())
