#!/usr/bin/env python3
"""Run the unchanged portable case with a selected DUT and the original helper."""
import argparse
import importlib.util
import json
import sys
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--image", required=True)
parser.add_argument("--output", required=True)
args = parser.parse_args()
source = Path(__file__).resolve().with_name("reproduce.py")
spec = importlib.util.spec_from_file_location("frr_reproducer", source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
helper_image = module.IMAGE
module.IMAGE = args.image
original_start = module.Run.start

def pinned_start(self, suffix, *container_args):
    if suffix == "peer":
        container_args = tuple(helper_image if arg == module.IMAGE else arg
                               for arg in container_args)
    result = original_start(self, suffix, *container_args)
    if suffix == "peer":
        (self.out / "helper-image.json").write_text(
            self.pod("inspect", result))
        (self.out / "runtime-inputs.json").write_text(json.dumps({
            "dut_image": module.IMAGE, "helper_image": helper_image,
            "canonical_reproducer": str(source),
            "observation_seconds": module.DURATION,
        }, indent=2) + "\n")
    return result

module.Run.start = pinned_start
sys.argv = [str(source), "--output", args.output]
sys.exit(module.main())
