# Graceful restart route-retention reproducer

One stable IPv6 helper, no exporter or Kubernetes, the same kernel network
namespace across router restart, and 120-second router restart/selection timers.
Setup verifies a fresh helper OPEN with its restart bit clear. Both runs retain
the original pinned FRR 10.6.2 helper image.

Requires Linux, Python 3, rootless Podman with IPv6 bridge networking, and locally
built FRR Alpine images containing Python/iproute2 and the standard
`/usr/lib/frr/docker-start` entrypoint. DUT images must already be present.

```sh
podman pull quay.io/frrouting/frr@sha256:89e5e1ec8b17c5dffaf57dbac58a29ebeb3731a84e5bc09dad1662adff2ba7f5
python3 run-runtime.py --image YOUR_BASELINE_IMAGE --output before
python3 run-runtime.py --image YOUR_PATCHED_IMAGE --output after
```

Each observation runs 135 seconds. Exit 1 means a reliable complete route dump
observed the target absent; 0 means no absence observed; 2 means inconclusive.
Inspect the summary for cadence/errors/loss and router logs for completion after
replay. These bounded observations do not measure continuous packet forwarding.

Only uniquely labeled owned containers/networks are cleaned. Inputs/logs remain
in each new output directory. Host sysctls and firewall rules are unchanged.
The wrapper selects the DUT image and keeps the helper pinned; the reproduction
and observer code are identical to the validated versions.
